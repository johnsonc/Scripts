/////////////////////////////////////////////////////////////////////////
// PureVirtual.cpp - demonstrate definition of pure virtual function   //
//                   based on question submitted by Karthik Parthiban  //
//                                                                     //
// Jim Fawcett, CSE687 - Object Oriented Design, Spring 2009           //
/////////////////////////////////////////////////////////////////////////

#include <iostream>

class Abstract_Base
{
public:
  virtual void func()=0;
};
void Abstract_Base::func() { std::cout<<"\n  From A\n\n";}
 
class Not_Abstract : public Abstract_Base
{
public:
  virtual void func() { Abstract_Base::func(); }
};
 
int main()
{
  Abstract_Base* pObj = new Not_Abstract;
  pObj->func();
  delete pObj;
}
 
